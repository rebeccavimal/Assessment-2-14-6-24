<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_EDI</name>
   <tag></tag>
   <elementGuidId>f2190857-236c-49e8-88f3-7d448c9152bc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mainnav-dropdown-1</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@id='mainnav-dropdown-1']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;EDI&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>df714f98-cd65-4077-80af-f7150d23be12</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-toggle show</value>
      <webElementGuid>b4db5540-d580-4ac4-9928-95fea3f2b049</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>fa9984b1-47ed-478e-b2ca-0e7b3ce1c6da</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>mainnav-dropdown-1</value>
      <webElementGuid>7652401e-a2a1-47b9-872b-b245fa425664</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-bs-toggle</name>
      <type>Main</type>
      <value>dropdown</value>
      <webElementGuid>e34e7a9f-cf76-4877-a98a-0ef0eaa7691f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-haspopup</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>0c21a59f-7881-4afa-9fd9-4d75486a2f85</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-expanded</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>b0a10fcd-399f-4629-8cf3-376af665aebe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            EDI
            
                
                    
                
            
        </value>
      <webElementGuid>b7edc7e7-b4b9-40d5-9c58-c8c4d9095ac7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mainnav-dropdown-1&quot;)</value>
      <webElementGuid>8f3688a9-c7fc-4d7b-bacd-7fe4e84f6bea</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@id='mainnav-dropdown-1']</value>
      <webElementGuid>bb63afc9-37ef-4a93-9fed-6182b90d1484</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='offcanvas-navbar']/ul/li[2]/div/button</value>
      <webElementGuid>72d1fbdd-1cd4-4331-97ae-49d040d70877</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='EDI']/parent::*</value>
      <webElementGuid>84296242-0068-4ce6-8e5b-b8f210cacf60</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/div/button</value>
      <webElementGuid>9c37694c-80b6-4760-ab52-3e95d418188e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[@type = 'button' and @id = 'mainnav-dropdown-1' and (text() = '
            EDI
            
                
                    
                
            
        ' or . = '
            EDI
            
                
                    
                
            
        ')]</value>
      <webElementGuid>ca0bb404-00b7-4b5b-ab72-33a18c15f5e9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
