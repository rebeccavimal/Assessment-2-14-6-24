<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_School of Chemistry News Bulletins</name>
   <tag></tag>
   <elementGuidId>39a3be42-1fe1-4152-a82e-a93a89e2da7b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.dropdown-menu.show > ul.dropdown-menu--list.p-0.m-0 > li:nth-of-type(3) > a.dropdown-item</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/div/ul/li[3]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;School of Chemistry News Bulletins&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>029b1b3a-72c3-4dd2-9d35-81e6eaf9eb9d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item</value>
      <webElementGuid>36c220e1-1386-40a2-aa60-65858b1ebba4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/newsevents/schoolofchemistrynewsbulletins/</value>
      <webElementGuid>66a4211d-1e7e-449c-bbb7-b1ca373c9509</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_self</value>
      <webElementGuid>801e2895-4696-44d3-b361-b00e3a6786f9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                School of Chemistry News Bulletins
            </value>
      <webElementGuid>fbf12079-0eda-4747-b91d-39424e9deac4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;offcanvas-navbar&quot;)/ul[@class=&quot;navbar-nav ms-auto visible-links&quot;]/li[@class=&quot;nav-item&quot;]/div[@class=&quot;dropdown&quot;]/div[@class=&quot;dropdown-menu show&quot;]/ul[@class=&quot;dropdown-menu--list p-0 m-0&quot;]/li[3]/a[@class=&quot;dropdown-item&quot;]</value>
      <webElementGuid>886bce44-2c52-478b-854c-d6f4cb029f20</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/div/ul/li[3]/a</value>
      <webElementGuid>192b3e9c-c74f-4773-8de4-aff232568b22</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='School of Chemistry News Bulletins']/parent::*</value>
      <webElementGuid>76d7102e-098b-4923-9f58-18954b6ea27f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/newsevents/schoolofchemistrynewsbulletins/')]</value>
      <webElementGuid>fa18dc2a-7208-4eaf-b18e-ed13e8108ca6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/div/div/ul/li[3]/a</value>
      <webElementGuid>087d2f94-1f7b-4841-93cd-02942a6cd3fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/newsevents/schoolofchemistrynewsbulletins/' and (text() = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                School of Chemistry News Bulletins
            ' or . = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                School of Chemistry News Bulletins
            ')]</value>
      <webElementGuid>cfed4fc5-c57e-4e30-9d8e-08b20cb2ea75</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
