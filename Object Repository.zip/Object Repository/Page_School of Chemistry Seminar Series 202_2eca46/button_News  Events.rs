<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_News  Events</name>
   <tag></tag>
   <elementGuidId>ba4ba727-8304-494d-b3ef-c2964ecdcf1f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mainnav-dropdown-4</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@id='mainnav-dropdown-4']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;News &amp; Events&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>2570c513-1338-487c-ac34-e9ae9e6d1b65</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-toggle show</value>
      <webElementGuid>5ad391f5-2cf3-47d6-8644-06894502828a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>3b285d82-e75e-4059-8e87-a7ab24ee0cdc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>mainnav-dropdown-4</value>
      <webElementGuid>40ab635f-50ee-40d3-afb3-e4a5c6132869</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-bs-toggle</name>
      <type>Main</type>
      <value>dropdown</value>
      <webElementGuid>a8baa777-48a5-4da6-9f21-1ba35e9d2348</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-haspopup</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>1c61cd86-a109-46df-bbcd-aa160747dd0e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-expanded</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>d1a22756-1abb-4337-a35a-9608dc35986f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            News &amp; Events
            
                
                    
                
            
        </value>
      <webElementGuid>75a8ed39-67da-4c09-a7c2-14235ca01bdd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mainnav-dropdown-4&quot;)</value>
      <webElementGuid>47323480-3bf4-4437-b63f-39540fb7acdd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@id='mainnav-dropdown-4']</value>
      <webElementGuid>b8a42aa5-4e89-431e-8d1c-328bfd8c580a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/button</value>
      <webElementGuid>89b3ccf0-4c90-4fea-bacb-d293a06825c6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='News &amp; Events']/parent::*</value>
      <webElementGuid>f2c73df4-c58e-449e-8c2c-433ee6729d3d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/div/button</value>
      <webElementGuid>7cf7c660-9c35-4834-b5a0-3f338f5cf8b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[@type = 'button' and @id = 'mainnav-dropdown-4' and (text() = '
            News &amp; Events
            
                
                    
                
            
        ' or . = '
            News &amp; Events
            
                
                    
                
            
        ')]</value>
      <webElementGuid>e38e0428-ea3d-4134-aaa9-2ab963c3a3b6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
