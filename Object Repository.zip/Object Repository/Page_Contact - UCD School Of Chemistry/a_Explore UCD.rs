<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Explore UCD</name>
   <tag></tag>
   <elementGuidId>8fa77a3b-e108-4607-afdd-408ea1ceac34</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.navbar__button.navbar__button--explore.navbar__button--blue</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Close'])[2]/following::a[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Explore UCD&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>755016aa-07d1-4467-87bc-b4112fecdea6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>javascript:;</value>
      <webElementGuid>076917d1-c499-40b1-921d-9625fefee259</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>navbar__button navbar__button--explore navbar__button--blue</value>
      <webElementGuid>7d485084-24f4-47f7-acae-7514c44728e8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>314c6dc6-6bd5-42e1-b9fb-b1b63e7d8276</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-bs-toggle</name>
      <type>Main</type>
      <value>collapse</value>
      <webElementGuid>eb17f9d4-3d8d-48ff-9957-9426b8a26589</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-controls</name>
      <type>Main</type>
      <value>explore</value>
      <webElementGuid>36db147d-ea85-4a72-be29-7e69e873405b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-expanded</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>96b1265d-a970-493e-8533-c90f1a219254</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Go to 'Explore' page</value>
      <webElementGuid>db92adb5-0288-457c-bbf9-1eb765774ff3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    


                    Explore UCD
                </value>
      <webElementGuid>61467756-8e46-4570-9566-c9b71ebd4302</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;body&quot;]/nav[@class=&quot;navbar navbar-expand-xl fixed-top&quot;]/div[@class=&quot;container-fluid&quot;]/div[@class=&quot;navbar__subnav&quot;]/a[@class=&quot;navbar__button navbar__button--explore navbar__button--blue&quot;]</value>
      <webElementGuid>e97d3598-9e9a-4bb6-89ff-e6acafa1184f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Close'])[2]/following::a[1]</value>
      <webElementGuid>754358e1-5042-4068-a734-de987d163e35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Menu'])[2]/following::a[1]</value>
      <webElementGuid>182cb17e-1331-41c9-aee8-8475a50b3405</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UCD Connect'])[1]/preceding::a[1]</value>
      <webElementGuid>5dbd005f-ba44-4308-80fd-ef38fd7d62ff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'javascript:;')]</value>
      <webElementGuid>c61e5690-36d9-4e8e-83ec-998a2f1bc396</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/a</value>
      <webElementGuid>46d0d32f-cd4d-4b71-9035-00adf6aee348</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'javascript:;' and @title = concat(&quot;Go to &quot; , &quot;'&quot; , &quot;Explore&quot; , &quot;'&quot; , &quot; page&quot;) and (text() = '
                    


                    Explore UCD
                ' or . = '
                    


                    Explore UCD
                ')]</value>
      <webElementGuid>83206672-ba17-4c3d-83e2-33b4f7c08f1e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
