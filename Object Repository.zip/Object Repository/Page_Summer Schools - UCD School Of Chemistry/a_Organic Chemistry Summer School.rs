<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Organic Chemistry Summer School</name>
   <tag></tag>
   <elementGuidId>3ac383f4-5ba9-4fd0-aa19-c4b4dc474e25</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.component-17__link</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='h671166']/div/div/div/div[2]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Group of Summer School Students outside UCD O'Brien Centre for Science Organic Chemistry Summer School&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>b4014cab-968f-481f-a2be-6597eddf502d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/study/summerschools/organicchemistrysummerschool/</value>
      <webElementGuid>ee46371b-4c6c-414b-b1ce-fd49a8cd8426</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>component-17__link</value>
      <webElementGuid>616099e9-682b-413c-b641-64e277b53044</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Go to 'Organic Chemistry Summer School' page</value>
      <webElementGuid>22996f92-69df-4612-a493-91cdbaf095d2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                      
                                Organic Chemistry Summer School
                            </value>
      <webElementGuid>f93cf709-85c7-4203-bceb-107896e8d968</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;h671166&quot;)/div[@class=&quot;component-17&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;component-17__panel&quot;]/div[@class=&quot;component-17__item component-17__item--blue component-17__item--half-overlay&quot;]/a[@class=&quot;component-17__link&quot;]</value>
      <webElementGuid>f0aaae4e-ffc6-482e-b400-48fdef7f541a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='h671166']/div/div/div/div[2]/a</value>
      <webElementGuid>575dbc60-5916-4b98-bd9e-0613ea23bb20</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Summer School for ZJNU Students'])[1]/following::a[1]</value>
      <webElementGuid>b7a9a3d3-847a-429a-bbea-b0dcea83f287</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Summer Schools'])[2]/following::a[1]</value>
      <webElementGuid>f122b042-d182-46c8-a2e6-0caa9efd30a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact UCD School of Chemistry'])[1]/preceding::a[1]</value>
      <webElementGuid>d215cc4e-14b5-4d27-a45e-72da53e4fb3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/study/summerschools/organicchemistrysummerschool/')]</value>
      <webElementGuid>05d7f692-63e4-4d03-ad28-54855ca00203</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[2]/a</value>
      <webElementGuid>f2faeac1-429a-454d-a384-6eb0797f758f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/study/summerschools/organicchemistrysummerschool/' and @title = concat(&quot;Go to &quot; , &quot;'&quot; , &quot;Organic Chemistry Summer School&quot; , &quot;'&quot; , &quot; page&quot;) and (text() = '
                      
                                Organic Chemistry Summer School
                            ' or . = '
                      
                                Organic Chemistry Summer School
                            ')]</value>
      <webElementGuid>b4d16fc2-3b0e-4f21-bbec-38669e9291f3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
