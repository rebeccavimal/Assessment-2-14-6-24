<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_News Archive</name>
   <tag></tag>
   <elementGuidId>a99b1716-f34c-46cd-9433-7cc1208c6fcd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(20) > a.dropdown-item</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/div/ul/li[20]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:label=&quot;News &amp; Events&quot;i >> internal:role=link[name=&quot;News Archive&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>ac23b297-2c27-4eb8-9031-1e2cd17a15e3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item</value>
      <webElementGuid>16a1a775-a317-4d2e-b543-7b7e96866413</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/newsevents/newsarchive/</value>
      <webElementGuid>72e9d318-e30b-4ebf-9d58-efa54cf33d9f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_self</value>
      <webElementGuid>0aa3f650-57fc-48f5-b6d5-392972f4c6d5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                News Archive
            </value>
      <webElementGuid>e46b58a8-a0e7-4b46-b081-1fd839366b7f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;offcanvas-navbar&quot;)/ul[@class=&quot;navbar-nav ms-auto visible-links&quot;]/li[@class=&quot;nav-item&quot;]/div[@class=&quot;dropdown&quot;]/div[@class=&quot;dropdown-menu show&quot;]/ul[@class=&quot;dropdown-menu--list p-0 m-0&quot;]/li[20]/a[@class=&quot;dropdown-item&quot;]</value>
      <webElementGuid>ac96b867-a537-4564-b32a-cb6540a42262</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/div/ul/li[20]/a</value>
      <webElementGuid>11705843-609b-4fc9-b123-5d4b67234c68</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[1]/preceding::a[1]</value>
      <webElementGuid>91b126c9-26f3-4337-8c26-cbf814211315</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Vacancies'])[1]/preceding::a[2]</value>
      <webElementGuid>4d3fe933-ddb0-45c1-a12e-679e35a517cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='News Archive']/parent::*</value>
      <webElementGuid>bc8c677a-305b-41ae-bec9-421eeccbb8e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/newsevents/newsarchive/')]</value>
      <webElementGuid>44442eb1-8512-4876-9173-5356529ed28d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[20]/a</value>
      <webElementGuid>383ee174-05a7-4392-8d58-9a72010d5133</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/newsevents/newsarchive/' and (text() = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                News Archive
            ' or . = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                News Archive
            ')]</value>
      <webElementGuid>7e4577d7-9fa2-4a93-aa50-9f51501d8771</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
