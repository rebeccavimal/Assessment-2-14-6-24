<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_School of Chemistry Welcomes New Academics 2023</name>
   <tag></tag>
   <elementGuidId>33a54026-4743-43a3-9206-0926e042c464</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(17) > a.dropdown-item</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/div/ul/li[17]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;School of Chemistry Welcomes New Academics 2023&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>25c1fee3-735e-400f-946a-2c685025b499</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item</value>
      <webElementGuid>9d40dd5b-4593-473d-a5d1-f293fdce3d89</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/newsevents/schoolofchemistrywelcomesnewacademics2023/</value>
      <webElementGuid>2a158c63-b6c1-4f98-962a-a2bdecc1cb8c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_self</value>
      <webElementGuid>da19793e-c816-4e06-8d19-7ae8c9b8d5ed</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                School of Chemistry Welcomes New Academics 2023
            </value>
      <webElementGuid>dbf5b349-9ee3-4c08-b770-1646d17b5376</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;offcanvas-navbar&quot;)/ul[@class=&quot;navbar-nav ms-auto visible-links&quot;]/li[@class=&quot;nav-item&quot;]/div[@class=&quot;dropdown&quot;]/div[@class=&quot;dropdown-menu show&quot;]/ul[@class=&quot;dropdown-menu--list p-0 m-0&quot;]/li[17]/a[@class=&quot;dropdown-item&quot;]</value>
      <webElementGuid>dd0daf7a-9fe3-49a3-81c1-deb1f0759b6c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/div/ul/li[17]/a</value>
      <webElementGuid>03edf6a0-4572-497d-a62a-09879473e9b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='School of Chemistry Welcomes New Academics 2023']/parent::*</value>
      <webElementGuid>d84074f5-29e9-4583-b4dd-e7717894d606</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/newsevents/schoolofchemistrywelcomesnewacademics2023/')]</value>
      <webElementGuid>e401cbb3-1101-4ece-ac31-44e17cd6eac3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[17]/a</value>
      <webElementGuid>dbd56153-9fac-492c-b6ce-71acd0883f29</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/newsevents/schoolofchemistrywelcomesnewacademics2023/' and (text() = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                School of Chemistry Welcomes New Academics 2023
            ' or . = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                School of Chemistry Welcomes New Academics 2023
            ')]</value>
      <webElementGuid>06640c9b-d6ab-42f0-ab1b-b2752ebe6cea</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
