<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Chemistry Conferring September 2023</name>
   <tag></tag>
   <elementGuidId>6de09419-db09-425c-aaa2-344171183d77</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.dropdown-menu.show > ul.dropdown-menu--list.p-0.m-0 > li:nth-of-type(9) > a.dropdown-item</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/div/ul/li[9]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Chemistry Conferring September 2023&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>30edd9b1-f5c6-4245-8faa-fdc4a62ad37c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item</value>
      <webElementGuid>fc8d76d1-4ed8-4c32-beeb-a08daea26bbf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/newsevents/chemistryconferringseptember2023/</value>
      <webElementGuid>a7d6f45b-e757-4371-814a-63e154a5a94d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_self</value>
      <webElementGuid>9d4b8cf6-fe05-49e4-ba78-ddd7ef2cc15d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Chemistry Conferring September 2023
            </value>
      <webElementGuid>6c65d1d3-ef35-4049-947f-01ec073752dd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;offcanvas-navbar&quot;)/ul[@class=&quot;navbar-nav ms-auto visible-links&quot;]/li[@class=&quot;nav-item&quot;]/div[@class=&quot;dropdown&quot;]/div[@class=&quot;dropdown-menu show&quot;]/ul[@class=&quot;dropdown-menu--list p-0 m-0&quot;]/li[9]/a[@class=&quot;dropdown-item&quot;]</value>
      <webElementGuid>b83a2b2b-7c91-4e0c-ae20-f811bad4a1f6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/div/ul/li[9]/a</value>
      <webElementGuid>aac4d35c-f803-4ecd-ad66-850ff643f2ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Chemistry Conferring September 2023']/parent::*</value>
      <webElementGuid>73f66862-c01f-4c75-8fa3-ef13dc428eef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/newsevents/chemistryconferringseptember2023/')]</value>
      <webElementGuid>b22ad3df-ed06-49fd-a2f0-81a46365ed78</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/div/div/ul/li[9]/a</value>
      <webElementGuid>4d363874-b234-443a-aea6-271cfe749bd1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/newsevents/chemistryconferringseptember2023/' and (text() = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Chemistry Conferring September 2023
            ' or . = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Chemistry Conferring September 2023
            ')]</value>
      <webElementGuid>9ff0f6e8-7e5f-482d-b969-981b0105448a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
