<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_News  Events</name>
   <tag></tag>
   <elementGuidId>4e1851ca-3939-45d3-b556-58eeb3e52bcf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mainnav-dropdown-4</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@id='mainnav-dropdown-4']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;News &amp; Events&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>46e1c762-0789-499b-bcaa-1aa6c7509d54</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-toggle show</value>
      <webElementGuid>021060fa-1c43-4e7d-89f6-c871a4bf7a17</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>5baee965-25d6-4629-ae00-b8c8f5378835</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>mainnav-dropdown-4</value>
      <webElementGuid>41c37d7e-16aa-4676-95ef-5a9c330ea485</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-bs-toggle</name>
      <type>Main</type>
      <value>dropdown</value>
      <webElementGuid>fbd6c780-3ab9-4b6e-bf82-925527919c2f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-haspopup</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>1917677f-57b6-416e-b03f-0d9ddbd7154c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-expanded</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>e0d54a75-3ad6-4227-a7c0-bb97ca0af352</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            News &amp; Events
            
                
                    
                
            
        </value>
      <webElementGuid>d8420c44-52fe-4e39-8337-a9b6217e662c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mainnav-dropdown-4&quot;)</value>
      <webElementGuid>5e97d755-903f-40bd-aec7-ad3e4ec7fc56</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@id='mainnav-dropdown-4']</value>
      <webElementGuid>36910848-4213-48f1-b4c3-775bffda5fd1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/button</value>
      <webElementGuid>0b60f178-f43a-47d1-9303-94226b65f7e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='News &amp; Events']/parent::*</value>
      <webElementGuid>baad0dec-c195-426c-99cd-cb3176c4cfda</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/div/button</value>
      <webElementGuid>e6283348-07f9-4d12-b0db-186c8e6ff593</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[@type = 'button' and @id = 'mainnav-dropdown-4' and (text() = '
            News &amp; Events
            
                
                    
                
            
        ' or . = '
            News &amp; Events
            
                
                    
                
            
        ')]</value>
      <webElementGuid>5f281ab3-f3dd-4cc6-9a13-47212d110724</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
