<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_News  Events</name>
   <tag></tag>
   <elementGuidId>9144de23-7fec-4e65-9748-fc511e62537b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mainnav-dropdown-4</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@id='mainnav-dropdown-4']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;News &amp; Events&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>abb1eece-039b-4399-b0dd-50645be1a5ab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-toggle show</value>
      <webElementGuid>ab056852-4c55-49ca-acb0-99ad40998f42</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>afc54598-a2b1-41c2-9477-cb9af704a365</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>mainnav-dropdown-4</value>
      <webElementGuid>e035a559-6caf-4422-9f24-55cc7ef9c48e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-bs-toggle</name>
      <type>Main</type>
      <value>dropdown</value>
      <webElementGuid>968f4194-6a00-417b-b562-cd7ae99d4424</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-haspopup</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>77611924-f908-498a-a562-e677c68283c7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-expanded</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>6671b7ba-190d-4422-8a88-3b03656c067d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            News &amp; Events
            
                
                    
                
            
        </value>
      <webElementGuid>41388a0e-2d1a-4afb-9cfc-b2d840aa0f31</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mainnav-dropdown-4&quot;)</value>
      <webElementGuid>e2d55062-f71c-460a-886f-ce25dfda500d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@id='mainnav-dropdown-4']</value>
      <webElementGuid>c409a44a-4532-4095-b272-f3976a9c71c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/button</value>
      <webElementGuid>08fe87e3-ffff-4b5b-bedb-c0fb7ec04c8e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='News &amp; Events']/parent::*</value>
      <webElementGuid>58c7d27a-3617-4ada-b2df-349c6045593f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/div/button</value>
      <webElementGuid>3914a685-b715-4a4d-b3fa-add51934f677</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[@type = 'button' and @id = 'mainnav-dropdown-4' and (text() = '
            News &amp; Events
            
                
                    
                
            
        ' or . = '
            News &amp; Events
            
                
                    
                
            
        ')]</value>
      <webElementGuid>87efec65-7c4e-4086-af6a-09ac2927733b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
