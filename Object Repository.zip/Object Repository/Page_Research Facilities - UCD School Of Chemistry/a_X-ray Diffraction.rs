<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_X-ray Diffraction</name>
   <tag></tag>
   <elementGuidId>ad3213e9-3a77-43f5-a603-45057da35bff</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Go to 'X-ray Diffraction' page&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='h672531']/div/div/div/div[2]/div/ul/li[4]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;X-ray Diffraction&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>0064f1f4-e17a-4bc1-b040-ef916462f56c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/about/ourfacilities/coretechnologies/x-raydiffractionlaboratory/</value>
      <webElementGuid>087d1213-911f-4d2f-b889-14bf2a7a09d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Go to 'X-ray Diffraction' page</value>
      <webElementGuid>b8385a8f-9b11-4a4a-b929-2c1f89e57501</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>X-ray Diffraction
   
    
   </value>
      <webElementGuid>08259d13-ee00-435c-b688-83e7373028fd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;h672531&quot;)/div[@class=&quot;component-18&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12 col-lg-6&quot;]/div[@class=&quot;component-18__content component__content&quot;]/ul[@class=&quot;component-18__cols&quot;]/li[4]/a[1]</value>
      <webElementGuid>b49b6ac4-dbac-465c-838b-033f2f77c3ab</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='h672531']/div/div/div/div[2]/div/ul/li[4]/a</value>
      <webElementGuid>b476b0c5-4426-46e8-b291-461c1d0da29a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'X-ray Diffraction')]</value>
      <webElementGuid>58f551f4-f6af-42e0-bad8-b6a144a684a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Elemental Microanalysis'])[1]/following::a[1]</value>
      <webElementGuid>09ff011b-5e45-4452-8146-c5ded432a429</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mass Spectrometry'])[1]/following::a[2]</value>
      <webElementGuid>31e0c99a-4d8d-4a2f-886b-e011eb05cb45</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chromotagraphy'])[1]/preceding::a[1]</value>
      <webElementGuid>acc39d14-6efd-4824-956d-41433da7a613</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact UCD School of Chemistry'])[1]/preceding::a[2]</value>
      <webElementGuid>e4917d14-8955-4045-a131-76b51c2b32b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='X-ray Diffraction']/parent::*</value>
      <webElementGuid>87820caa-f8a9-4120-a48d-8ae680c7e0c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/about/ourfacilities/coretechnologies/x-raydiffractionlaboratory/')]</value>
      <webElementGuid>6b3acaf8-854d-4d0d-9dd6-7d4130f39594</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[2]/div/ul/li[4]/a</value>
      <webElementGuid>b668c46c-c42e-4a4d-bfef-13b9d22ada93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/about/ourfacilities/coretechnologies/x-raydiffractionlaboratory/' and @title = concat(&quot;Go to &quot; , &quot;'&quot; , &quot;X-ray Diffraction&quot; , &quot;'&quot; , &quot; page&quot;) and (text() = 'X-ray Diffraction
   
    
   ' or . = 'X-ray Diffraction
   
    
   ')]</value>
      <webElementGuid>61230920-55ee-4dba-84e1-6ed988b14598</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
