<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Elemental Microanalysis</name>
   <tag></tag>
   <elementGuidId>6fabca14-c433-4ed9-9a29-eac82a639a40</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Go to 'Elemental Microanalysis' page&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='h672531']/div/div/div/div[2]/div/ul/li[3]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Elemental Microanalysis&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>3e5251a3-002d-48a8-9248-3d7e5110d0fd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/about/ourfacilities/coretechnologies/microanalysis/</value>
      <webElementGuid>471854b2-1ffb-41b0-8e00-23225ad05d3f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Go to 'Elemental Microanalysis' page</value>
      <webElementGuid>a98fece1-6007-410b-89ce-07c728a1316e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Elemental Microanalysis
   
    
   </value>
      <webElementGuid>55c2cefd-9476-45dc-8967-1f89a2afb97d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;h672531&quot;)/div[@class=&quot;component-18&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12 col-lg-6&quot;]/div[@class=&quot;component-18__content component__content&quot;]/ul[@class=&quot;component-18__cols&quot;]/li[3]/a[1]</value>
      <webElementGuid>bda83945-a547-41f8-b958-00066a93d8b9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='h672531']/div/div/div/div[2]/div/ul/li[3]/a</value>
      <webElementGuid>b5b94e08-8c69-45fe-9b3f-34c53d5526f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Elemental Microanalysis')]</value>
      <webElementGuid>098f4017-9dbe-4901-9fba-e27723a8272a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mass Spectrometry'])[1]/following::a[1]</value>
      <webElementGuid>ca8cdd6a-0a03-407a-84d2-bb15c5065108</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nuclear Magnetic Resonance (NMR) Spectroscopy'])[1]/following::a[2]</value>
      <webElementGuid>ff9a532a-cdb1-464a-ba35-82550443abf6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='X-ray Diffraction'])[1]/preceding::a[1]</value>
      <webElementGuid>b9c9026f-c144-431c-a89e-28a8f9b307e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chromotagraphy'])[1]/preceding::a[2]</value>
      <webElementGuid>8dfa3dea-cdd5-44f8-9257-e2e7da8a0bc7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Elemental Microanalysis']/parent::*</value>
      <webElementGuid>187201a7-e6ee-4a8b-886e-cf4fa6924337</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/about/ourfacilities/coretechnologies/microanalysis/')]</value>
      <webElementGuid>d6f84df9-2c4b-4174-aa38-4920063c2e53</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[2]/div/ul/li[3]/a</value>
      <webElementGuid>9ecd2444-4043-4581-be3e-da5401c116f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/about/ourfacilities/coretechnologies/microanalysis/' and @title = concat(&quot;Go to &quot; , &quot;'&quot; , &quot;Elemental Microanalysis&quot; , &quot;'&quot; , &quot; page&quot;) and (text() = 'Elemental Microanalysis
   
    
   ' or . = 'Elemental Microanalysis
   
    
   ')]</value>
      <webElementGuid>00589ba7-08cf-41d3-8382-20a609e36c06</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
