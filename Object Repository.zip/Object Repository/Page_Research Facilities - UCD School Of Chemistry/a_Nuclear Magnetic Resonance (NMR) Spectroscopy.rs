<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Nuclear Magnetic Resonance (NMR) Spectroscopy</name>
   <tag></tag>
   <elementGuidId>5186705c-a6b3-4649-91ac-4f984cc6ffa0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Go to 'Nuclear Magnetic Resonance (NMR) Spectroscopy' page&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='h672531']/div/div/div/div[2]/div/ul/li/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Nuclear Magnetic Resonance (NMR) Spectroscopy&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>4c06cc2a-9e0b-47ac-a522-c62014183254</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/about/ourfacilities/coretechnologies/nmrcentre/</value>
      <webElementGuid>2b0f73fb-ae10-41a5-88b7-8a422ef5c078</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Go to 'Nuclear Magnetic Resonance (NMR) Spectroscopy' page</value>
      <webElementGuid>29fc2d3e-885c-456a-a3d4-61d38608e419</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Nuclear Magnetic Resonance (NMR) Spectroscopy
   
    
   </value>
      <webElementGuid>be6f55e6-63b9-4440-85a0-2330d3885cd0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;h672531&quot;)/div[@class=&quot;component-18&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12 col-lg-6&quot;]/div[@class=&quot;component-18__content component__content&quot;]/ul[@class=&quot;component-18__cols&quot;]/li[1]/a[1]</value>
      <webElementGuid>e15a4636-9fc8-41d4-86cd-d2a6677c7c4a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='h672531']/div/div/div/div[2]/div/ul/li/a</value>
      <webElementGuid>c3cbf72b-bc06-49fd-b488-af00c1b6d2fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Nuclear Magnetic Resonance (NMR) Spectroscopy')]</value>
      <webElementGuid>8c0fe076-b84e-4ef5-934c-2745b0c83b8d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Research Facilities at UCD School of Chemistry'])[1]/following::a[1]</value>
      <webElementGuid>bed527f5-e320-438c-9f69-0d6338c6db92</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Research Facilities'])[2]/following::a[1]</value>
      <webElementGuid>08efc1be-2bf7-43a7-975a-021b2515793d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mass Spectrometry'])[1]/preceding::a[1]</value>
      <webElementGuid>3109285d-49c7-40b6-9095-4ac8e5370af9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Elemental Microanalysis'])[1]/preceding::a[2]</value>
      <webElementGuid>73c8b987-3084-427e-b888-4e7d753eed85</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Nuclear Magnetic Resonance (NMR) Spectroscopy']/parent::*</value>
      <webElementGuid>61ce64dd-8082-4d22-bb14-b8899920b949</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/about/ourfacilities/coretechnologies/nmrcentre/')]</value>
      <webElementGuid>686b1bda-5855-44c7-b178-2953313728f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[2]/div/ul/li/a</value>
      <webElementGuid>d79b2c0b-71f6-4d48-8a1f-0530b6300ef3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/about/ourfacilities/coretechnologies/nmrcentre/' and @title = concat(&quot;Go to &quot; , &quot;'&quot; , &quot;Nuclear Magnetic Resonance (NMR) Spectroscopy&quot; , &quot;'&quot; , &quot; page&quot;) and (text() = 'Nuclear Magnetic Resonance (NMR) Spectroscopy
   
    
   ' or . = 'Nuclear Magnetic Resonance (NMR) Spectroscopy
   
    
   ')]</value>
      <webElementGuid>79137d0b-0f38-4e17-bcf0-04fd1d918cd8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
