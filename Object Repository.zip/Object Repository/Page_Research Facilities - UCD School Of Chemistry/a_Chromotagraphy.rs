<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Chromotagraphy</name>
   <tag></tag>
   <elementGuidId>357af176-a0d5-4835-951b-574050f0d10b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Go to 'Chromotagraphy' page&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='h672531']/div/div/div/div[2]/div/ul/li[5]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Chromotagraphy&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>298ade75-85dc-444f-8da2-4c0098c666eb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/about/ourfacilities/coretechnologies/chromatography/</value>
      <webElementGuid>48d8bb72-3ac1-4c93-bdd0-7472298c6288</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Go to 'Chromotagraphy' page</value>
      <webElementGuid>3cdde2d5-cae9-4c57-a75c-d4dd2905edad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Chromotagraphy
   
    
   </value>
      <webElementGuid>33c68fc1-3af1-4948-9b6a-e61d58891203</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;h672531&quot;)/div[@class=&quot;component-18&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12 col-lg-6&quot;]/div[@class=&quot;component-18__content component__content&quot;]/ul[@class=&quot;component-18__cols&quot;]/li[5]/a[1]</value>
      <webElementGuid>1db85657-d6f0-480f-abf8-ac5b0e40fac7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='h672531']/div/div/div/div[2]/div/ul/li[5]/a</value>
      <webElementGuid>0c9606d6-9545-4769-bc08-0b3ed3fb3b90</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Chromotagraphy')]</value>
      <webElementGuid>a1aa98dc-738b-41a6-ae7f-8a9240e48aef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='X-ray Diffraction'])[1]/following::a[1]</value>
      <webElementGuid>3b444c53-82b4-47f4-84bc-d56b0b8944b8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Elemental Microanalysis'])[1]/following::a[2]</value>
      <webElementGuid>892ce735-f6b5-4c75-8047-098af79c79fb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact UCD School of Chemistry'])[1]/preceding::a[1]</value>
      <webElementGuid>0ed560ed-2b77-443d-8778-db95cd36881b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='University College Dublin, Belfield, Dublin 4, Ireland.'])[1]/preceding::a[1]</value>
      <webElementGuid>5e221bff-5dc2-4d54-aae1-98e5491f096f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Chromotagraphy']/parent::*</value>
      <webElementGuid>dfba7fa1-0622-4b1c-9632-e53e422eee72</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/about/ourfacilities/coretechnologies/chromatography/')]</value>
      <webElementGuid>391d23b8-f0d2-4c30-9377-4cd493620ce1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[2]/div/ul/li[5]/a</value>
      <webElementGuid>6e5e73c5-1851-484c-9b65-e210f02fba1c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/about/ourfacilities/coretechnologies/chromatography/' and @title = concat(&quot;Go to &quot; , &quot;'&quot; , &quot;Chromotagraphy&quot; , &quot;'&quot; , &quot; page&quot;) and (text() = 'Chromotagraphy
   
    
   ' or . = 'Chromotagraphy
   
    
   ')]</value>
      <webElementGuid>e37b830e-684f-4907-9691-db61662785ab</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
