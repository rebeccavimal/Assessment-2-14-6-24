<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_School of Chemistry Seminar Series 20232024</name>
   <tag></tag>
   <elementGuidId>1297a30a-dafa-4d5d-ba6d-b9325f904e93</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.dropdown-menu.show > ul.dropdown-menu--list.p-0.m-0 > li:nth-of-type(2) > a.dropdown-item</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/div/ul/li[2]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;School of Chemistry Seminar Series 2023/2024&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>06584b77-72d2-473e-be66-e45ce42195b1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item</value>
      <webElementGuid>85ad3492-607a-4d5e-8acf-d839b24c05c5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/newsevents/schoolofchemistryseminarseries20232024/</value>
      <webElementGuid>ec446e0d-4336-4181-84c1-eb2ecdfcc251</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_self</value>
      <webElementGuid>31712cd9-a95a-4ccc-9a3b-ee3bf6ea73a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                School of Chemistry Seminar Series 2023/2024
            </value>
      <webElementGuid>af72133e-577f-4114-985c-46ef292965ad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;offcanvas-navbar&quot;)/ul[@class=&quot;navbar-nav ms-auto visible-links&quot;]/li[@class=&quot;nav-item&quot;]/div[@class=&quot;dropdown&quot;]/div[@class=&quot;dropdown-menu show&quot;]/ul[@class=&quot;dropdown-menu--list p-0 m-0&quot;]/li[2]/a[@class=&quot;dropdown-item&quot;]</value>
      <webElementGuid>732bd108-47a8-4d38-9c7d-4d6261d54e62</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/div/ul/li[2]/a</value>
      <webElementGuid>91e887fc-fb8c-47ff-8e0e-d58ea249225e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='News &amp; Events'])[1]/following::a[2]</value>
      <webElementGuid>a7586838-3647-4b23-b1c3-11acd0816293</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='School of Chemistry Seminar Series 2023/2024']/parent::*</value>
      <webElementGuid>055f20ba-2741-41fd-ba2c-7d6cfeda9527</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/newsevents/schoolofchemistryseminarseries20232024/')]</value>
      <webElementGuid>22c3d80d-d89d-4b64-91ee-66fbfba4c22e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/div/div/ul/li[2]/a</value>
      <webElementGuid>2a745503-6971-4aa7-9bf5-6acc3bcc6ff8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/newsevents/schoolofchemistryseminarseries20232024/' and (text() = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                School of Chemistry Seminar Series 2023/2024
            ' or . = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                School of Chemistry Seminar Series 2023/2024
            ')]</value>
      <webElementGuid>7d0aa9f5-0a68-464a-aaf6-5f53139ede52</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
