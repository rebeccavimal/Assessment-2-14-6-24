<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Mass Spectrometry</name>
   <tag></tag>
   <elementGuidId>389cc4e5-fabf-4c42-9946-9ddbc802ab96</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Go to 'Mass Spectrometry' page&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='h672531']/div/div/div/div[2]/div/ul/li[2]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Mass Spectrometry&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>b91c24ed-efa3-41f0-92f3-04e8b0ec911a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/about/ourfacilities/coretechnologies/massspec/</value>
      <webElementGuid>435ed301-ee8e-4c76-b781-6c992f2391dd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Go to 'Mass Spectrometry' page</value>
      <webElementGuid>62a60e82-0c6e-4b6f-9f63-04bca9403f6c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Mass Spectrometry
   
    
   </value>
      <webElementGuid>474c2d6d-4311-4bc4-9caf-84ac05e1370a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;h672531&quot;)/div[@class=&quot;component-18&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12 col-lg-6&quot;]/div[@class=&quot;component-18__content component__content&quot;]/ul[@class=&quot;component-18__cols&quot;]/li[2]/a[1]</value>
      <webElementGuid>0aa8afac-372d-4ea1-a896-2a190d8b5c0c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='h672531']/div/div/div/div[2]/div/ul/li[2]/a</value>
      <webElementGuid>4e7a75fa-63f4-4c13-8cae-e295685fba5d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Mass Spectrometry')]</value>
      <webElementGuid>d9fbd586-50d2-4809-b25e-4e46c21c9ec6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nuclear Magnetic Resonance (NMR) Spectroscopy'])[1]/following::a[1]</value>
      <webElementGuid>90412e76-8c94-4c30-ad3a-ed5ae931b5c2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Research Facilities at UCD School of Chemistry'])[1]/following::a[2]</value>
      <webElementGuid>3b6573df-9ab3-41c2-bd30-13435f008901</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Elemental Microanalysis'])[1]/preceding::a[1]</value>
      <webElementGuid>f16eb19b-f559-42e4-a0a9-d392093b8fd9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='X-ray Diffraction'])[1]/preceding::a[2]</value>
      <webElementGuid>e372a21b-a979-435f-ad96-f778690e5245</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Mass Spectrometry']/parent::*</value>
      <webElementGuid>3b108f2c-d5fa-45cd-a23b-f2363cc346f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/about/ourfacilities/coretechnologies/massspec/')]</value>
      <webElementGuid>2b899b0a-f6a7-4134-a316-b267be858fb9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[2]/div/ul/li[2]/a</value>
      <webElementGuid>af95ea8a-f50f-4c83-91ca-033639ec31c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/about/ourfacilities/coretechnologies/massspec/' and @title = concat(&quot;Go to &quot; , &quot;'&quot; , &quot;Mass Spectrometry&quot; , &quot;'&quot; , &quot; page&quot;) and (text() = 'Mass Spectrometry
   
    
   ' or . = 'Mass Spectrometry
   
    
   ')]</value>
      <webElementGuid>2acb6af2-56df-493e-9f9d-a7898f1f688d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
