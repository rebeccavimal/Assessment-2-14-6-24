<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Click here to download RISE Information</name>
   <tag></tag>
   <elementGuidId>93f585da-2471-47e0-bd1d-ec1351a83e44</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>section.section.section--component-21.component-21__green-bright > div.component-21 > div.container > a.component-21__link > span.component-21__title.heading-sm</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='.docx'])[1]/following::span[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot; Click here to download RISE Information .pdf | 0.1 MB&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>3e74b944-bbe0-4b0f-ab4f-48a41b06b16b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>component-21__title heading-sm</value>
      <webElementGuid>9a6c3666-6251-47d9-86b5-e062fd183553</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click here to download RISE Information </value>
      <webElementGuid>8ab69996-8b49-45de-a7a1-ab2b47dd345e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;body&quot;]/main[1]/section[@class=&quot;section section--component-21 component-21__green-bright&quot;]/div[@class=&quot;component-21&quot;]/div[@class=&quot;container&quot;]/a[@class=&quot;component-21__link&quot;]/span[@class=&quot;component-21__title heading-sm&quot;]</value>
      <webElementGuid>3e9cebd6-7d74-4965-858b-535b73c670dd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='.docx'])[1]/following::span[3]</value>
      <webElementGuid>6623cd54-500b-4bcf-ac88-3804fe0364a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='.pdf'])[1]/preceding::span[1]</value>
      <webElementGuid>251621e1-9c48-4752-a8d5-a6a222b3d302</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact UCD School of Chemistry'])[1]/preceding::span[4]</value>
      <webElementGuid>ae7f8db6-c07b-41cc-bad4-444643a0e9db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Click here to download RISE Information']/parent::*</value>
      <webElementGuid>2b369860-0d22-40f5-8b74-a22fb9230847</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[4]/div/div/a/span</value>
      <webElementGuid>e313f6d1-9570-4efd-88e9-affbcf366ccd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Click here to download RISE Information ' or . = 'Click here to download RISE Information ')]</value>
      <webElementGuid>d2db6f63-660d-4851-b5a5-9bed86b60929</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
