<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Click here to download RISE Application Form</name>
   <tag></tag>
   <elementGuidId>fc41b908-ce5a-43dd-b9a1-43d2a4eaaa09</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.component-21__title.heading-sm</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Year 3'])[1]/following::span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot; Click here to download RISE Application Form .docx | 0.21MB&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>c70f202c-5a53-40f3-b9f0-080a85f345a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>component-21__title heading-sm</value>
      <webElementGuid>c655a8e9-934a-4ca4-b455-e554e1a947a8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click here to download RISE Application Form</value>
      <webElementGuid>ef05d3c5-cf3f-4441-a98e-16a998c7ed48</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;body&quot;]/main[1]/section[@class=&quot;section section--component-21 component-21__blue&quot;]/div[@class=&quot;component-21&quot;]/div[@class=&quot;container&quot;]/a[@class=&quot;component-21__link&quot;]/span[@class=&quot;component-21__title heading-sm&quot;]</value>
      <webElementGuid>5638fdd5-c407-4f6f-8b0c-740e7a667011</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Year 3'])[1]/following::span[2]</value>
      <webElementGuid>e5625405-bf39-477b-9d2b-ddf2955697b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='.docx'])[1]/preceding::span[1]</value>
      <webElementGuid>7fce16f6-de1c-40a7-a6ef-6e8fa43e4c42</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Click here to download RISE Application Form']/parent::*</value>
      <webElementGuid>97b05cb5-d800-4783-8433-2e2f110a3f0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[3]/div/div/a/span</value>
      <webElementGuid>41656633-5857-4245-8775-763220ee14a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Click here to download RISE Application Form' or . = 'Click here to download RISE Application Form')]</value>
      <webElementGuid>418c6b49-e4bb-41d7-9d96-bad9565bd8d0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
