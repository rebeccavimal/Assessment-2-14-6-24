<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Undergraduate Programmes</name>
   <tag></tag>
   <elementGuidId>0f6a671e-0607-42ed-bedc-c7bef9a0486f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.dropdown-menu.show > ul.dropdown-menu--list.p-0.m-0 > li:nth-of-type(2) > a.dropdown-item</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='offcanvas-navbar']/ul/li[3]/div/div/ul/li[2]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Undergraduate Programmes&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>44020cbd-7d09-4867-a7ae-3bef0c4637a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item</value>
      <webElementGuid>53d17b2d-7011-44b1-b2ec-58f72e05e988</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/study/undergraduateprogrammes/</value>
      <webElementGuid>d059a8cd-73b6-4b9f-ab7f-62336fa2a662</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_self</value>
      <webElementGuid>fe3c2e67-9650-4fd8-b01b-2ac205483734</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Undergraduate Programmes
            </value>
      <webElementGuid>6c54e8d6-60bd-4ac9-b64e-da23323cd01d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;offcanvas-navbar&quot;)/ul[@class=&quot;navbar-nav ms-auto visible-links&quot;]/li[@class=&quot;nav-item&quot;]/div[@class=&quot;dropdown&quot;]/div[@class=&quot;dropdown-menu show&quot;]/ul[@class=&quot;dropdown-menu--list p-0 m-0&quot;]/li[2]/a[@class=&quot;dropdown-item&quot;]</value>
      <webElementGuid>2544b090-5172-4da1-9d89-3c2a28ec8365</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='offcanvas-navbar']/ul/li[3]/div/div/ul/li[2]/a</value>
      <webElementGuid>032b290e-ce89-4d17-a722-1719e78ccb48</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Study'])[1]/following::a[2]</value>
      <webElementGuid>8ae5708a-1cd5-4b7e-8c51-db5251412b7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Undergraduate Programmes']/parent::*</value>
      <webElementGuid>8b072796-0964-4e36-b6ad-bdbb1821ef47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/study/undergraduateprogrammes/')]</value>
      <webElementGuid>d1d9686e-4d31-49f7-81ab-a3fa4ecdacf9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/div/div/ul/li[2]/a</value>
      <webElementGuid>8b58e256-4596-4a62-b0e7-cefa767f3982</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/study/undergraduateprogrammes/' and (text() = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Undergraduate Programmes
            ' or . = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Undergraduate Programmes
            ')]</value>
      <webElementGuid>5f1b28eb-ed36-4f66-b1dc-556a64858ddd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
