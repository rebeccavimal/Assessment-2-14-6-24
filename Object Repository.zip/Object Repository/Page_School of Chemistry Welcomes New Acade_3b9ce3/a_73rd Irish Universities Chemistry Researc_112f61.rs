<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_73rd Irish Universities Chemistry Researc_112f61</name>
   <tag></tag>
   <elementGuidId>5602d687-ceec-44bf-96dc-15cc77f1607f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(19) > a.dropdown-item</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/div/ul/li[19]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;73rd Irish Universities Chemistry Research Colloquium&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>8867ca87-8d42-41cf-9e2c-19b1f7b94bac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item</value>
      <webElementGuid>a8c2efed-e36f-424a-9aca-23ab6683db6f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/newsevents/73rdirishuniversitieschemistryresearchcolloquium/</value>
      <webElementGuid>e856e22a-397b-46e7-8eb9-a6a445680fa1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_self</value>
      <webElementGuid>08b818bc-35e2-4d84-a2ef-9cab5cfe6c45</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                73rd Irish Universities Chemistry Research Colloquium
            </value>
      <webElementGuid>50a82f5a-85c8-424e-9aaf-7684fdc1e945</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;offcanvas-navbar&quot;)/ul[@class=&quot;navbar-nav ms-auto visible-links&quot;]/li[@class=&quot;nav-item&quot;]/div[@class=&quot;dropdown&quot;]/div[@class=&quot;dropdown-menu show&quot;]/ul[@class=&quot;dropdown-menu--list p-0 m-0&quot;]/li[19]/a[@class=&quot;dropdown-item&quot;]</value>
      <webElementGuid>e0b800c8-96d4-4827-8963-04f22d37fe43</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/div/ul/li[19]/a</value>
      <webElementGuid>6b1a1e77-b85f-48c5-ac80-123deeb408ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[1]/preceding::a[2]</value>
      <webElementGuid>f8c07239-abc9-4449-b96d-8f02d6f35e21</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='73rd Irish Universities Chemistry Research Colloquium']/parent::*</value>
      <webElementGuid>9dd84233-eac3-4ec2-b519-51a827ffad40</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/newsevents/73rdirishuniversitieschemistryresearchcolloquium/')]</value>
      <webElementGuid>af285013-e30e-4fb7-b329-6a5fc5331fc7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[19]/a</value>
      <webElementGuid>b7c3df6d-66c3-4168-b4cf-9e2c3145f90b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/newsevents/73rdirishuniversitieschemistryresearchcolloquium/' and (text() = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                73rd Irish Universities Chemistry Research Colloquium
            ' or . = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                73rd Irish Universities Chemistry Research Colloquium
            ')]</value>
      <webElementGuid>c277705f-4f53-4440-9819-d5d3ad6a2f50</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
