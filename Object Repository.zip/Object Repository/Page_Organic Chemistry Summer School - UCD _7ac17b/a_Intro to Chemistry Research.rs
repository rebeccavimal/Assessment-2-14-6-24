<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Intro to Chemistry Research</name>
   <tag></tag>
   <elementGuidId>69c6dbdf-4d86-437c-9c65-bc66aa1a0600</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.dropdown-menu.show > ul.dropdown-menu--list.p-0.m-0 > li:nth-of-type(2) > a.dropdown-item</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='offcanvas-navbar']/ul/li[4]/div/div/ul/li[2]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Intro to Chemistry Research&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>098f5373-e9a1-496b-954b-c8ca618fe8a7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item</value>
      <webElementGuid>6db18c2a-a283-4baa-84f7-a86e22197301</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/research/introtochemistryresearch/</value>
      <webElementGuid>b8fa93e3-f7d3-4b40-ad85-0a0d2592a705</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_self</value>
      <webElementGuid>61628ed0-ab67-48c7-8bee-37b719cf2a99</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Intro to Chemistry Research
            </value>
      <webElementGuid>c4c4762f-9421-4365-9418-40616e0fc173</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;offcanvas-navbar&quot;)/ul[@class=&quot;navbar-nav ms-auto visible-links&quot;]/li[@class=&quot;nav-item&quot;]/div[@class=&quot;dropdown&quot;]/div[@class=&quot;dropdown-menu show&quot;]/ul[@class=&quot;dropdown-menu--list p-0 m-0&quot;]/li[2]/a[@class=&quot;dropdown-item&quot;]</value>
      <webElementGuid>1e94177d-b4c1-4b1b-bee4-3ae62e169975</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='offcanvas-navbar']/ul/li[4]/div/div/ul/li[2]/a</value>
      <webElementGuid>f252e43a-85dd-44c0-96ca-63e89bfcd957</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Research'])[1]/following::a[2]</value>
      <webElementGuid>b4aab2fa-30ff-4f47-b917-2c916e5ecb33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Intro to Chemistry Research']/parent::*</value>
      <webElementGuid>c8716858-d0a1-471e-ac6b-f66d2d402549</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/research/introtochemistryresearch/')]</value>
      <webElementGuid>a05ba28a-6e8b-448c-9a70-7126d4fc8e40</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[4]/div/div/ul/li[2]/a</value>
      <webElementGuid>77932846-ae3c-434b-af1c-b39fbf80a73f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/research/introtochemistryresearch/' and (text() = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Intro to Chemistry Research
            ' or . = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Intro to Chemistry Research
            ')]</value>
      <webElementGuid>8a1c3f5d-96d7-4e83-bdb2-5f74f18888a3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
