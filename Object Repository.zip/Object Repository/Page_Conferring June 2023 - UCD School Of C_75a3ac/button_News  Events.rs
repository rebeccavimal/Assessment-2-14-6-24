<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_News  Events</name>
   <tag></tag>
   <elementGuidId>e65c9c56-9eed-4994-a482-b2f6fcd5ccc2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mainnav-dropdown-4</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@id='mainnav-dropdown-4']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;News &amp; Events&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>aec21aa4-c243-4215-8482-508cd1ab4eea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-toggle show</value>
      <webElementGuid>e589a9c6-3326-4e6f-9f1d-b7f3b9d191b0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>367fd528-af38-4f00-ba50-b4f76b324bdd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>mainnav-dropdown-4</value>
      <webElementGuid>ed6efc0c-aa68-4dd7-8b38-95a69219c551</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-bs-toggle</name>
      <type>Main</type>
      <value>dropdown</value>
      <webElementGuid>192735ff-ea99-478f-8dd3-5c5a7e7d6ddc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-haspopup</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>e7ebdce1-cdf6-4904-a35a-a31fdd7f3486</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-expanded</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>7eb6f4f7-05d4-4346-8994-8dcdcbd700c7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            News &amp; Events
            
                
                    
                
            
        </value>
      <webElementGuid>4b5d7ea0-892e-48d9-bc96-e578bf334a7f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mainnav-dropdown-4&quot;)</value>
      <webElementGuid>5c109c83-883d-443a-ae91-3579a0ec8025</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@id='mainnav-dropdown-4']</value>
      <webElementGuid>bcf76418-ba0e-4857-9e76-1c7862096561</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/button</value>
      <webElementGuid>76907dd1-5fe1-4fe1-93fa-7917761f9365</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='News &amp; Events']/parent::*</value>
      <webElementGuid>4fe55920-d48b-4ab4-a3fc-346af0aa53e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/div/button</value>
      <webElementGuid>72eb8d48-9901-4d31-8001-0cffc49ee375</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[@type = 'button' and @id = 'mainnav-dropdown-4' and (text() = '
            News &amp; Events
            
                
                    
                
            
        ' or . = '
            News &amp; Events
            
                
                    
                
            
        ')]</value>
      <webElementGuid>b1b004ec-a05a-479a-aefb-a034df60998c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
