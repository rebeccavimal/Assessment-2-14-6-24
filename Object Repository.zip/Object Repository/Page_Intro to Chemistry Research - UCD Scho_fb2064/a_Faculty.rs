<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Faculty</name>
   <tag></tag>
   <elementGuidId>e0d78996-a4f0-4655-be70-c75b9c105f28</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.dropdown-menu.show > ul.dropdown-menu--list.p-0.m-0 > li:nth-of-type(3) > a.dropdown-item</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='offcanvas-navbar']/ul/li[4]/div/div/ul/li[3]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Faculty&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>b998000b-5a34-423a-8e39-1a692f26570b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item</value>
      <webElementGuid>488327d0-f333-44c3-a3aa-91c7401d9129</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/research/faculty/</value>
      <webElementGuid>3d3b6793-cc4d-4b06-ba29-a584e1ee64d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_self</value>
      <webElementGuid>b2027bcf-bde5-4fff-b97f-2f076ad7dc03</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Faculty
            </value>
      <webElementGuid>4d9fa65f-13a2-4f96-81d6-2ec8bb6fb41b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;offcanvas-navbar&quot;)/ul[@class=&quot;navbar-nav ms-auto visible-links&quot;]/li[@class=&quot;nav-item&quot;]/div[@class=&quot;dropdown&quot;]/div[@class=&quot;dropdown-menu show&quot;]/ul[@class=&quot;dropdown-menu--list p-0 m-0&quot;]/li[3]/a[@class=&quot;dropdown-item&quot;]</value>
      <webElementGuid>2338c297-4346-4abe-ae4f-21bc6a4ff330</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='offcanvas-navbar']/ul/li[4]/div/div/ul/li[3]/a</value>
      <webElementGuid>877b469d-114b-461e-86a0-44c5c159aa4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='News &amp; Events'])[1]/preceding::a[2]</value>
      <webElementGuid>64b7ba9a-fc90-49fb-be5f-cfebcab94199</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Faculty']/parent::*</value>
      <webElementGuid>f1ce78f3-892e-4b74-bac7-b4f18fc46057</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/research/faculty/')]</value>
      <webElementGuid>1f4bd84d-7b2c-404b-a49f-4f8538f84287</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[4]/div/div/ul/li[3]/a</value>
      <webElementGuid>a9b57c4d-98bf-49fa-8d3c-f2073b42cdf1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/research/faculty/' and (text() = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Faculty
            ' or . = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Faculty
            ')]</value>
      <webElementGuid>74ca2c54-6000-41a2-a439-b30a0933a6f9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
