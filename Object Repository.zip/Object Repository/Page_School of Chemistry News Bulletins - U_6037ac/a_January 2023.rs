<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_January 2023</name>
   <tag></tag>
   <elementGuidId>d0692dbc-af7b-4567-922c-1aa5028a343d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Go to 'January 2023' page&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'January 2023')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;January 2023&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>39eb2061-1b80-4eca-a707-5a0385256f78</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/t4media/School News January 2023.pdf</value>
      <webElementGuid>290e45ed-5925-45f8-8329-11581a09be10</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>4aa6fec3-a4ed-4738-a7de-df517e62f180</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Go to 'January 2023' page</value>
      <webElementGuid>e2a123b5-a8a0-44a6-943e-d4e53e4ad601</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>January 2023</value>
      <webElementGuid>a90e5975-73f3-43dd-a340-6244b5572f5a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;body&quot;]/main[1]/section[@class=&quot;section section--component-19  rectangle  rectangle--small rectangle--green-top-left rectangle--blend-off section--order-lg-inverted&quot;]/div[@class=&quot;component-19&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12&quot;]/p[19]/a[1]</value>
      <webElementGuid>65473762-e6ea-457b-a90c-9603a18c5729</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'January 2023')]</value>
      <webElementGuid>a036f445-3113-426d-9b4a-ddccaf721aa2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='February 2023'])[1]/following::a[1]</value>
      <webElementGuid>e4a6b506-3367-4789-a6d7-8d6ae36bed77</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='March 2023'])[1]/following::a[2]</value>
      <webElementGuid>b0e3c7d1-db3a-4421-a87d-51d24d05d80a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='December 2022'])[1]/preceding::a[1]</value>
      <webElementGuid>e7eac73c-509d-46df-8f99-977b0b7994ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='November 2022'])[1]/preceding::a[2]</value>
      <webElementGuid>863402bc-8011-4be1-830c-e96d4c47c02c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='January 2023']/parent::*</value>
      <webElementGuid>d9d68b5d-9e47-4c75-b75d-8e21ecb58e20</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/t4media/School News January 2023.pdf')]</value>
      <webElementGuid>536cbb2b-b08a-4e2c-9549-8d9f4595c2db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[19]/a</value>
      <webElementGuid>810a162d-4637-41c2-be18-3448113a9903</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/t4media/School News January 2023.pdf' and @title = concat(&quot;Go to &quot; , &quot;'&quot; , &quot;January 2023&quot; , &quot;'&quot; , &quot; page&quot;) and (text() = 'January 2023' or . = 'January 2023')]</value>
      <webElementGuid>db7554e0-30a6-4e36-9eb7-f7a717462568</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
