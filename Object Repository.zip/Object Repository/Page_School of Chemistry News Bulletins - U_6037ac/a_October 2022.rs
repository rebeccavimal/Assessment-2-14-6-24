<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_October 2022</name>
   <tag></tag>
   <elementGuidId>ac2a032d-befd-4d7c-a8e5-d18ed8801ef1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Go to 'October 2022' page&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'October 2022')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;October 2022&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>3b7eb542-6105-434b-95eb-2a13ab2f09de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/t4media/School of Chemistry News October 2022 (2).pdf</value>
      <webElementGuid>65b87922-f463-4e4f-941d-d382fdfb057c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>fb43485d-75b0-4cf9-9efc-c6e00224db9c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Go to 'October 2022' page</value>
      <webElementGuid>4174c694-b759-48fe-878b-bd6f4f67d557</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>October 2022</value>
      <webElementGuid>53002e26-03f8-4102-8577-1fd694b4bce1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;body&quot;]/main[1]/section[@class=&quot;section section--component-19  rectangle  rectangle--small rectangle--green-top-left rectangle--blend-off section--order-lg-inverted&quot;]/div[@class=&quot;component-19&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12&quot;]/p[22]/a[1]</value>
      <webElementGuid>62691536-5c0d-4e3f-8290-c9ffb379d529</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'October 2022')]</value>
      <webElementGuid>57b95be7-bebd-41c0-ba68-9da3da280450</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='November 2022'])[1]/following::a[1]</value>
      <webElementGuid>330a8329-5b14-46ae-8030-3e41ee5445c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='December 2022'])[1]/following::a[2]</value>
      <webElementGuid>c3d02d0c-066e-428b-af17-8ffd19e2cf85</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact UCD School of Chemistry'])[1]/preceding::a[1]</value>
      <webElementGuid>1f46893e-17a7-4a62-87f3-478cd8174bfb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='University College Dublin, Belfield, Dublin 4, Ireland.'])[1]/preceding::a[1]</value>
      <webElementGuid>d2826eb2-9e7e-4a4b-b02b-8e6ad7762ff5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='October 2022']/parent::*</value>
      <webElementGuid>7ef20791-22f4-44d3-9b5d-b01f90eba24d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/t4media/School of Chemistry News October 2022 (2).pdf')]</value>
      <webElementGuid>d2fbae92-84e2-48b5-8e97-07b0e60ad313</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[22]/a</value>
      <webElementGuid>02591148-e704-4f95-876b-5712a7ac1e6b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/t4media/School of Chemistry News October 2022 (2).pdf' and @title = concat(&quot;Go to &quot; , &quot;'&quot; , &quot;October 2022&quot; , &quot;'&quot; , &quot; page&quot;) and (text() = 'October 2022' or . = 'October 2022')]</value>
      <webElementGuid>1809e4bf-603f-4acb-87d3-f2a506127721</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
