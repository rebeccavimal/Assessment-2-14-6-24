<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_The School of Chemistry news is compile_4d2981</name>
   <tag></tag>
   <elementGuidId>844b061e-84c0-4337-8455-1b61c3cd3885</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.component-19 > div.container > div.row > div.col-12</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='School of Chemistry News Bulletins'])[2]/following::div[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div >> internal:has-text=&quot;The School of Chemistry news is compiled on a monthly basis and we include items&quot;i >> nth=3</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>15d0553f-f4d5-4a74-a2f4-79179727eb50</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-12</value>
      <webElementGuid>22221412-ebd9-42f2-8ae8-61f15cc42e76</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                               
The School of Chemistry news is compiled on a monthly basis and we include items such as events, staff promotions, publications, welcome new staff and students, celebrating awards and prize winners, PhD Viva Voce celebrations and conferrings. The news is circulated by email to all staff, graduate students and Stage 3 and 4 undergraduate students. See the archive below.  
2023/2024 
May-June 2024 
April 2024 
March 2024 
February 2024 
January 2024 
December 2023 
October 2023 
September 2023 
_________________________________________________________________________________________________________________________________________________________________ 
2022/2023 
Summer (June, July &amp; August) 2023 
May 2023 
April 2023 
 March 2023 
February 2023 
January 2023 
December 2022 
November 2022 
October 2022
                    </value>
      <webElementGuid>8abce16a-83e5-4b24-b129-80f47f77d8dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;body&quot;]/main[1]/section[@class=&quot;section section--component-19  rectangle  rectangle--small rectangle--green-top-left rectangle--blend-off section--order-lg-inverted&quot;]/div[@class=&quot;component-19&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12&quot;]</value>
      <webElementGuid>4a78c054-9445-471a-bbb4-b83acdd262e5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='School of Chemistry News Bulletins'])[2]/following::div[4]</value>
      <webElementGuid>e6bf811c-67db-4e88-ad8e-54b62cc2d972</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='News &amp; Events'])[2]/following::div[4]</value>
      <webElementGuid>a2fc4114-9765-42e5-8ea6-49d6708c4ec4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[2]/div/div/div/div</value>
      <webElementGuid>72c5aef9-c5fb-47f0-9aa2-72c1e2f56f56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                               
The School of Chemistry news is compiled on a monthly basis and we include items such as events, staff promotions, publications, welcome new staff and students, celebrating awards and prize winners, PhD Viva Voce celebrations and conferrings. The news is circulated by email to all staff, graduate students and Stage 3 and 4 undergraduate students. See the archive below.  
2023/2024 
May-June 2024 
April 2024 
March 2024 
February 2024 
January 2024 
December 2023 
October 2023 
September 2023 
_________________________________________________________________________________________________________________________________________________________________ 
2022/2023 
Summer (June, July &amp; August) 2023 
May 2023 
April 2023 
 March 2023 
February 2023 
January 2023 
December 2022 
November 2022 
October 2022
                    ' or . = '
                               
The School of Chemistry news is compiled on a monthly basis and we include items such as events, staff promotions, publications, welcome new staff and students, celebrating awards and prize winners, PhD Viva Voce celebrations and conferrings. The news is circulated by email to all staff, graduate students and Stage 3 and 4 undergraduate students. See the archive below.  
2023/2024 
May-June 2024 
April 2024 
March 2024 
February 2024 
January 2024 
December 2023 
October 2023 
September 2023 
_________________________________________________________________________________________________________________________________________________________________ 
2022/2023 
Summer (June, July &amp; August) 2023 
May 2023 
April 2023 
 March 2023 
February 2023 
January 2023 
December 2022 
November 2022 
October 2022
                    ')]</value>
      <webElementGuid>dfa3aeb2-1cca-4a51-b3b2-d01e91e8019e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
