<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_May-June 2024</name>
   <tag></tag>
   <elementGuidId>1de95f27-30a8-41c5-9eae-0e59c1d4c7c4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Go to 'May-June 2024' page&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'May-June 2024')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;May-June 2024&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>dd7e1484-5cd7-4e67-bae4-f2a0b3a7e0d7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/t4media/School News May-June2024.pdf</value>
      <webElementGuid>8ef65ccb-c595-4c57-a594-dffc63ef6a93</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>9e1d53de-6ac4-461a-ac03-1d78ef5c1f13</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Go to 'May-June 2024' page</value>
      <webElementGuid>4996bf99-7614-486f-bf4f-d43efc842a38</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>May-June 2024</value>
      <webElementGuid>dbf76001-feb6-480d-bbd4-551e57b44cc1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;body&quot;]/main[1]/section[@class=&quot;section section--component-19  rectangle  rectangle--small rectangle--green-top-left rectangle--blend-off section--order-lg-inverted&quot;]/div[@class=&quot;component-19&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12&quot;]/p[4]/a[1]</value>
      <webElementGuid>9a181f97-ae6a-4ca1-adc1-cc8bc0d7915d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'May-June 2024')]</value>
      <webElementGuid>e139a3b0-cf48-4ced-87f2-0e736b816c0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='School of Chemistry News Bulletins'])[2]/following::a[1]</value>
      <webElementGuid>031b0ea4-c022-417c-bd8b-94f65e263fec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='News &amp; Events'])[2]/following::a[2]</value>
      <webElementGuid>872adc02-ec59-443a-90fb-ce707791736d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='April 2024'])[1]/preceding::a[1]</value>
      <webElementGuid>35b757e9-f70d-448d-a9cb-eb41184d2e18</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='March 2024'])[1]/preceding::a[2]</value>
      <webElementGuid>4c65d68e-d4cd-467f-bba9-d686468d52db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='May-June 2024']/parent::*</value>
      <webElementGuid>eaba16ab-6fc6-4aa2-a2d3-2b7ce4152060</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/t4media/School News May-June2024.pdf')]</value>
      <webElementGuid>db2d54e2-8032-427e-af38-4a8c25c77b9c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[4]/a</value>
      <webElementGuid>e6d252a7-be21-4a3f-8b77-d6a81bc2a258</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/t4media/School News May-June2024.pdf' and @title = concat(&quot;Go to &quot; , &quot;'&quot; , &quot;May-June 2024&quot; , &quot;'&quot; , &quot; page&quot;) and (text() = 'May-June 2024' or . = 'May-June 2024')]</value>
      <webElementGuid>a71167b0-edbe-4618-96cd-49542e0cc603</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
