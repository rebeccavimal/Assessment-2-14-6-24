<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_September 2023</name>
   <tag></tag>
   <elementGuidId>f5190169-0d21-4a2f-9ab2-381c06fe3d29</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Go to 'September 2023' page&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'September 2023')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;September 2023&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>45bccace-8980-46c5-80ff-402b5448e30a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/t4media/School News September 2023.pdf</value>
      <webElementGuid>9a07a61f-49b0-47de-8ceb-72501c6ca16f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>9f6bdf39-adde-4773-aae6-d60292d3b23a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Go to 'September 2023' page</value>
      <webElementGuid>f51ba8eb-62b0-453e-9b23-d4a336aac3ca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>September 2023</value>
      <webElementGuid>b3df15bc-3d1b-4bb1-a8b9-0c7556a14893</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;body&quot;]/main[1]/section[@class=&quot;section section--component-19  rectangle  rectangle--small rectangle--green-top-left rectangle--blend-off section--order-lg-inverted&quot;]/div[@class=&quot;component-19&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12&quot;]/p[11]/a[1]</value>
      <webElementGuid>2c7b96a8-16e4-4605-8977-8ec14373f85d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'September 2023')]</value>
      <webElementGuid>e5c0d277-9109-4acc-ad85-25ccfe2ba5a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='October 2023'])[1]/following::a[1]</value>
      <webElementGuid>2fc6e757-1289-47de-99f9-b39770924733</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='December 2023'])[1]/following::a[2]</value>
      <webElementGuid>3855012b-9dba-4546-b1f7-d1d6dc9436eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Summer (June, July &amp; August) 2023'])[1]/preceding::a[1]</value>
      <webElementGuid>0a372824-86b5-476d-8a82-4b485568923c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='May 2023'])[1]/preceding::a[2]</value>
      <webElementGuid>e0a24808-3bb2-4726-90f9-7e4796a1e163</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='September 2023']/parent::*</value>
      <webElementGuid>141f5c5c-dfaf-44af-9c03-567bc9a3919b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/t4media/School News September 2023.pdf')]</value>
      <webElementGuid>ca901a60-dc6f-4c19-9fed-7171118eeeff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[11]/a</value>
      <webElementGuid>afdaa955-9bf9-4738-945a-86997dab496b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/t4media/School News September 2023.pdf' and @title = concat(&quot;Go to &quot; , &quot;'&quot; , &quot;September 2023&quot; , &quot;'&quot; , &quot; page&quot;) and (text() = 'September 2023' or . = 'September 2023')]</value>
      <webElementGuid>843e8b41-0d16-4a34-b2e7-e1adc983525f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
