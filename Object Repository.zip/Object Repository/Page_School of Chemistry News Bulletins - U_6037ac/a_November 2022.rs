<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_November 2022</name>
   <tag></tag>
   <elementGuidId>44af8784-486b-47fd-b4ed-2d19b6b0e429</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Go to 'November 2022' page&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'November 2022')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;November 2022&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>9f303ecb-85a6-4de6-a11e-5771e72dd9db</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/t4media/School of Chemistry November 2022 News.pdf</value>
      <webElementGuid>7026d188-5fe1-4ef8-bfe9-9845659fdd47</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>48ad0917-548a-4c6c-80c0-e23c39dc581e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Go to 'November 2022' page</value>
      <webElementGuid>0c7d9d49-b369-4469-89bf-fcd7a1c2d300</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>November 2022</value>
      <webElementGuid>627b25f6-5609-4cf5-8781-bc086d9869d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;body&quot;]/main[1]/section[@class=&quot;section section--component-19  rectangle  rectangle--small rectangle--green-top-left rectangle--blend-off section--order-lg-inverted&quot;]/div[@class=&quot;component-19&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12&quot;]/p[21]/a[1]</value>
      <webElementGuid>dd28cc41-0b07-471a-a03c-321745e8720b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'November 2022')]</value>
      <webElementGuid>b6711839-910c-4add-a650-9da447ff79c6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='December 2022'])[1]/following::a[1]</value>
      <webElementGuid>4a839e23-4fc5-4707-8338-255a7991f2b7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='January 2023'])[1]/following::a[2]</value>
      <webElementGuid>ef05dcc5-fe31-422d-ba4b-05e1ae6aefba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='October 2022'])[1]/preceding::a[1]</value>
      <webElementGuid>a7a71d03-2325-448b-9dc5-69b053b303d9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact UCD School of Chemistry'])[1]/preceding::a[2]</value>
      <webElementGuid>ac8885de-1172-402b-8b3e-b45275779dae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='November 2022']/parent::*</value>
      <webElementGuid>955d82fd-ec18-4c5e-b1a6-219526aa192c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/t4media/School of Chemistry November 2022 News.pdf')]</value>
      <webElementGuid>54a3698f-3ff9-40b8-81d2-d7deddcbf2b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[21]/a</value>
      <webElementGuid>0d191049-bada-4bcc-9a88-49c9d0905b7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/t4media/School of Chemistry November 2022 News.pdf' and @title = concat(&quot;Go to &quot; , &quot;'&quot; , &quot;November 2022&quot; , &quot;'&quot; , &quot; page&quot;) and (text() = 'November 2022' or . = 'November 2022')]</value>
      <webElementGuid>43a80762-3cd1-4198-9f83-b2b68eb3d96e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
