<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_March 2024</name>
   <tag></tag>
   <elementGuidId>4bb1a38c-d906-4836-8b7d-ff9d783406f0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Go to 'March 2024' page&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'March 2024')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;March 2024&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>b0de3888-d723-48cc-b6eb-c6b5169a4d23</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/t4media/School of Chemistry News March 2024.pdf</value>
      <webElementGuid>956aafad-e2bf-4822-8bec-bb1065dd14cd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>3bbe6f0f-1f0c-4052-a502-708f7179de6c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Go to 'March 2024' page</value>
      <webElementGuid>aebe17f4-4535-43be-a58f-e5f407d7d3c2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>March 2024</value>
      <webElementGuid>0f19e8d6-fe68-4928-aaef-1f0dca1fdfb0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;body&quot;]/main[1]/section[@class=&quot;section section--component-19  rectangle  rectangle--small rectangle--green-top-left rectangle--blend-off section--order-lg-inverted&quot;]/div[@class=&quot;component-19&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12&quot;]/p[6]/a[1]</value>
      <webElementGuid>66f3bbf5-955d-4c8b-9c1c-c186552acc97</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'March 2024')]</value>
      <webElementGuid>bbd2a404-373e-4b7a-8afa-54a527ed160e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='April 2024'])[1]/following::a[1]</value>
      <webElementGuid>9a905cfa-b859-497a-8b6c-c4dde17ea099</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='May-June 2024'])[1]/following::a[2]</value>
      <webElementGuid>55a20951-fc1a-4a8d-a478-cb0491fd91ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='February 2024'])[1]/preceding::a[1]</value>
      <webElementGuid>8dbf2eb6-a6f1-41a7-8581-3a21092e7d1b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='January 2024'])[1]/preceding::a[2]</value>
      <webElementGuid>f4bac296-02e7-4304-aca4-cc8cfe99cad1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='March 2024']/parent::*</value>
      <webElementGuid>831f016d-caff-4456-b6c8-b3ab632e47e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/t4media/School of Chemistry News March 2024.pdf')]</value>
      <webElementGuid>a32eb8f6-652c-4080-b565-287f2e25723d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[6]/a</value>
      <webElementGuid>e32cb5c3-437e-4892-b636-dc4295e6e5a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/t4media/School of Chemistry News March 2024.pdf' and @title = concat(&quot;Go to &quot; , &quot;'&quot; , &quot;March 2024&quot; , &quot;'&quot; , &quot; page&quot;) and (text() = 'March 2024' or . = 'March 2024')]</value>
      <webElementGuid>e8a7acdb-4726-465a-89d5-8b7e7c34edd9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
