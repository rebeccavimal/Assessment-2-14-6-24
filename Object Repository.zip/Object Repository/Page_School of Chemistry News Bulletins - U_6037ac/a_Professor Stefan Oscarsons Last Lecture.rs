<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Professor Stefan Oscarsons Last Lecture</name>
   <tag></tag>
   <elementGuidId>2c65b65f-b4f5-4788-a9d2-ea879b78aaf4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.dropdown-menu.show > ul.dropdown-menu--list.p-0.m-0 > li:nth-of-type(4) > a.dropdown-item</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/div/ul/li[4]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Professor Stefan Oscarson's Last Lecture&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>ccadee44-ed0d-411c-bcef-8c33859f6d60</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item</value>
      <webElementGuid>ed299a5c-6ae2-413a-9675-9bf8a51a71da</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/newsevents/professorstefanoscarsonslastlecture/</value>
      <webElementGuid>c58a6b99-e089-4fce-9f70-cd14a0605f50</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_self</value>
      <webElementGuid>c49365ad-f3e7-4353-a949-3556a038627c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Professor Stefan Oscarson's Last Lecture
            </value>
      <webElementGuid>aed0c525-61c8-4476-889d-01e700845809</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;offcanvas-navbar&quot;)/ul[@class=&quot;navbar-nav ms-auto visible-links&quot;]/li[@class=&quot;nav-item&quot;]/div[@class=&quot;dropdown&quot;]/div[@class=&quot;dropdown-menu show&quot;]/ul[@class=&quot;dropdown-menu--list p-0 m-0&quot;]/li[4]/a[@class=&quot;dropdown-item&quot;]</value>
      <webElementGuid>a1ff4edd-c62c-46ea-af0d-1d419e20eab0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='offcanvas-navbar']/ul/li[5]/div/div/ul/li[4]/a</value>
      <webElementGuid>9c56b3e5-08b9-4312-9421-062e209c2906</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/newsevents/professorstefanoscarsonslastlecture/')]</value>
      <webElementGuid>85920570-4329-43e0-bf56-b1d2d4a59f8b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/div/div/ul/li[4]/a</value>
      <webElementGuid>3238b820-d82f-43fe-a6bc-72e37e484ab2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/newsevents/professorstefanoscarsonslastlecture/' and (text() = concat(&quot;
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Professor Stefan Oscarson&quot; , &quot;'&quot; , &quot;s Last Lecture
            &quot;) or . = concat(&quot;
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Professor Stefan Oscarson&quot; , &quot;'&quot; , &quot;s Last Lecture
            &quot;))]</value>
      <webElementGuid>2c5c1c1d-d10b-4cbb-8274-427849a1cd62</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
