<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Contact UCD School of Chemistry</name>
   <tag></tag>
   <elementGuidId>af54e546-ff57-4c02-8430-4ae8524d2fb5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h2.heading-xl</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='about UCD School of Chemistry'])[2]/following::h2[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Contact UCD School of Chemistry&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>b244797e-c453-4102-9b83-0439c4ffda86</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>heading-xl</value>
      <webElementGuid>3dd440d2-e680-42ae-877a-9f4537586208</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Contact UCD School of Chemistry</value>
      <webElementGuid>a7849175-0155-4982-a60b-c3a6e72b32be</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;body&quot;]/main[1]/section[@class=&quot;section section--component-5&quot;]/div[@class=&quot;component-5&quot;]/div[@class=&quot;container&quot;]/h2[@class=&quot;heading-xl&quot;]</value>
      <webElementGuid>29dbd9c3-1452-4561-b81a-4839171f9128</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='about UCD School of Chemistry'])[2]/following::h2[1]</value>
      <webElementGuid>10c1ec9a-66a4-45c6-907d-3d1128ee0118</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='University College Dublin, Belfield, Dublin 4, Ireland.'])[1]/preceding::h2[1]</value>
      <webElementGuid>6c3dcbe2-41e6-4d4d-ae53-5316b76593e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Contact UCD School of Chemistry']/parent::*</value>
      <webElementGuid>4d884800-6fa7-44f4-bfe3-e83d6895a1e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[2]/div/div/h2</value>
      <webElementGuid>885ed16c-9218-4c32-b30e-b34f02e4cf86</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Contact UCD School of Chemistry' or . = 'Contact UCD School of Chemistry')]</value>
      <webElementGuid>4ec70046-f190-47df-8235-3ab5fb39697a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
