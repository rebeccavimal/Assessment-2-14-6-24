<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_2024 All Rights Reserved_col-md-3 col-l_d70c9b</name>
   <tag></tag>
   <elementGuidId>2dd57270-556b-494a-92a8-6eb4c36641b4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.col-md-3.col-lg-2.col-lg-2--collapsible.footer__collapsible-col-1</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='©2024 All Rights Reserved.'])[1]/following::div[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>.row > div:nth-child(3)</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>9c709890-bcc0-44f5-be4e-a4a825f9d0b4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-md-3 col-lg-2 col-lg-2--collapsible footer__collapsible-col-1</value>
      <webElementGuid>c4e8f69d-031b-4971-b101-a61b87750d2c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;body&quot;]/footer[@class=&quot;footer&quot;]/div[@class=&quot;footer__content&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3 col-lg-2 col-lg-2--collapsible footer__collapsible-col-1&quot;]</value>
      <webElementGuid>8f8ebaa3-8def-433a-9058-30984695aa2a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='©2024 All Rights Reserved.'])[1]/following::div[1]</value>
      <webElementGuid>b9758819-f278-4b5e-8604-3f9d1a91f1f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='T: +353 1 716 7777'])[1]/following::div[1]</value>
      <webElementGuid>efc8ecac-73f5-4d68-954d-b5050c3f82b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Useful Links'])[1]/preceding::div[2]</value>
      <webElementGuid>cf8cd994-8055-44b2-8134-28b22e3442bc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='A - Z'])[1]/preceding::div[2]</value>
      <webElementGuid>0e169411-d75c-40ae-ba63-e97ecf8537c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div[3]</value>
      <webElementGuid>b30a1588-fdd6-4df7-97ed-fda39e9feb2b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
