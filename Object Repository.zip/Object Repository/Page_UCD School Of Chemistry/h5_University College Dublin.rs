<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h5_University College Dublin</name>
   <tag></tag>
   <elementGuidId>1a9c6024-7503-4ae0-a546-677e2fac6040</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h5</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='(opens in a new window)'])[12]/following::h5[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;University College Dublin&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h5</value>
      <webElementGuid>7bb82e91-b29a-4a1f-a271-3ba24b593d3c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>University College Dublin</value>
      <webElementGuid>98217049-fe58-4ede-aaa9-c2c17d575be4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;body&quot;]/footer[@class=&quot;footer&quot;]/div[@class=&quot;footer__content&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3 col-lg-4 footer__contactinfo&quot;]/h5[1]</value>
      <webElementGuid>d2410d31-87b3-4263-9d67-68a5b97c592f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(opens in a new window)'])[12]/following::h5[1]</value>
      <webElementGuid>78886830-fbe1-4a90-9279-3a474b8cb3d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='chemistry@ucd.ie'])[1]/following::h5[1]</value>
      <webElementGuid>0da8e9aa-f231-41c0-b653-a4c2f2ca2b64</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Belfield,'])[1]/preceding::h5[1]</value>
      <webElementGuid>77615c42-ed73-435f-b62a-e3312560ef0b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dublin 4, Ireland.'])[1]/preceding::h5[1]</value>
      <webElementGuid>6eeb2564-3d00-4166-848a-8a6a3f0bfc25</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='University College Dublin']/parent::*</value>
      <webElementGuid>c4812c02-77b0-42f9-aa18-7519597011b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h5</value>
      <webElementGuid>7f5c6f26-abcd-4d01-ac1f-7f5cf23cf81b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h5[(text() = 'University College Dublin' or . = 'University College Dublin')]</value>
      <webElementGuid>e8991331-e565-4c58-a45d-f4d06d5d49e8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
