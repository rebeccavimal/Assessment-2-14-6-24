<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Dublin 4, Ireland</name>
   <tag></tag>
   <elementGuidId>97e12a78-7c4f-4cdb-a6e4-b0061fc52220</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.footer__list > li:nth-of-type(2)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Belfield,'])[1]/following::li[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Dublin 4, Ireland.&quot;s</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>c18969fa-7a00-4c6c-82f9-a19d4c45e606</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Dublin 4, Ireland.</value>
      <webElementGuid>b1936194-5102-4d76-acf9-29c2cea0f8e9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;body&quot;]/footer[@class=&quot;footer&quot;]/div[@class=&quot;footer__content&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3 col-lg-4 footer__contactinfo&quot;]/ul[@class=&quot;footer__list&quot;]/li[2]</value>
      <webElementGuid>e70f75af-f91c-416d-8d55-17c0260672a1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Belfield,'])[1]/following::li[1]</value>
      <webElementGuid>5f21f395-2d84-45ec-9962-55a5cf69eb73</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='University College Dublin'])[1]/following::li[2]</value>
      <webElementGuid>e179e2d0-6824-4fac-b526-ccaf92c31506</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='T: +353 1 716 7777'])[1]/preceding::li[1]</value>
      <webElementGuid>6a927c3b-e8cf-4b31-93c7-2dc8d65dfb0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='©2024 All Rights Reserved.'])[1]/preceding::li[2]</value>
      <webElementGuid>3418f311-eca8-4358-a0be-6a337ad8e4ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Dublin 4, Ireland.']/parent::*</value>
      <webElementGuid>33e2d615-e6f6-4b92-ab9e-1e9c93bfe19d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div[2]/ul/li[2]</value>
      <webElementGuid>f107db4b-111a-4673-9d2f-460393c3063f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'Dublin 4, Ireland.' or . = 'Dublin 4, Ireland.')]</value>
      <webElementGuid>1ccf74c7-0f2c-40ab-8b09-8d224e57bbb1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
