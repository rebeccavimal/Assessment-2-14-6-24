<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Gaeilge san Ollscoil</name>
   <tag></tag>
   <elementGuidId>52bd42d8-8a1d-4258-bc3a-43aa6661b51d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Go to 'Gaeilge san Ollscoil' page&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='footer-collapse-3']/li[2]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Gaeilge san Ollscoil&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>90d84ce6-42a2-461e-b036-559d05e4ff39</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/ucdgaeilge/</value>
      <webElementGuid>5212fb0b-9446-4310-96e9-35eedcfa6b8a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Go to 'Gaeilge san Ollscoil' page</value>
      <webElementGuid>cf4694ab-daff-41d1-ac77-714b75eb21a5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Gaeilge san Ollscoil</value>
      <webElementGuid>eae6d387-a2b0-4377-830d-d5a7716070d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;footer-collapse-3&quot;)/li[2]/a[1]</value>
      <webElementGuid>0ba1c536-1782-48d3-a0d0-74f8501c5b58</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//ul[@id='footer-collapse-3']/li[2]/a</value>
      <webElementGuid>8d743e57-fb2f-48cf-84d0-53f1385d8857</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Gaeilge san Ollscoil')]</value>
      <webElementGuid>87a26ad2-c535-40f0-bc3b-c378727234b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='A - Z'])[1]/following::a[1]</value>
      <webElementGuid>9b637a2c-7f00-42f8-bc75-87c6b906d089</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Useful Links'])[1]/following::a[2]</value>
      <webElementGuid>98cde461-5d5f-4a68-8f6b-334ca0d28b4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Privacy'])[1]/preceding::a[1]</value>
      <webElementGuid>30ed8863-433b-47da-9e0f-fb0c4b01924d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cookie Policy'])[1]/preceding::a[2]</value>
      <webElementGuid>4e24ef7d-2ebb-422b-b294-5952bca82263</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Gaeilge san Ollscoil']/parent::*</value>
      <webElementGuid>f9fbcfff-9e03-4fb0-8eaf-bd81c034bdc0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/ucdgaeilge/')]</value>
      <webElementGuid>5d0f383c-4cf2-41a4-a1b7-95aa96d4fc4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div[5]/ul/li[2]/a</value>
      <webElementGuid>e474968c-6907-476f-a46f-587400dc2a34</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/ucdgaeilge/' and @title = concat(&quot;Go to &quot; , &quot;'&quot; , &quot;Gaeilge san Ollscoil&quot; , &quot;'&quot; , &quot; page&quot;) and (text() = 'Gaeilge san Ollscoil' or . = 'Gaeilge san Ollscoil')]</value>
      <webElementGuid>15e49879-5a36-4e02-9112-6eebc476500a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
