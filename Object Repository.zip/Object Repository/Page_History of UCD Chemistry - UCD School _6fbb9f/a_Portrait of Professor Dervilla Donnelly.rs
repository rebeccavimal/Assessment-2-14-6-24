<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Portrait of Professor Dervilla Donnelly</name>
   <tag></tag>
   <elementGuidId>e5960908-80bd-461c-99c6-e06cdfb5d436</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(8) > a.dropdown-item</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='offcanvas-navbar']/ul/li/div/div/ul/li[8]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Portrait of Professor Dervilla Donnelly&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>f501c04c-6a97-4516-88df-01549f420dfa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>dropdown-item</value>
      <webElementGuid>21a81759-cadd-4d3d-b2eb-e7e00a3a7146</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chem/about/portraitofprofessordervilladonnelly/</value>
      <webElementGuid>5f1adea6-97ca-4afa-9cac-4b2c6989ed0e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_self</value>
      <webElementGuid>de5f4e39-9bd7-42f7-bfcb-d6ae9b8e46a2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Portrait of Professor Dervilla Donnelly
            </value>
      <webElementGuid>c99bf482-456f-4340-9f40-e58892e307e4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;offcanvas-navbar&quot;)/ul[@class=&quot;navbar-nav ms-auto visible-links&quot;]/li[@class=&quot;nav-item&quot;]/div[@class=&quot;dropdown&quot;]/div[@class=&quot;dropdown-menu show&quot;]/ul[@class=&quot;dropdown-menu--list p-0 m-0&quot;]/li[8]/a[@class=&quot;dropdown-item&quot;]</value>
      <webElementGuid>f2131d5d-1e22-4cd9-9f23-f5dcbd295fbc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='offcanvas-navbar']/ul/li/div/div/ul/li[8]/a</value>
      <webElementGuid>615ec2b4-fb24-4a27-aed6-a655652ef6e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EDI'])[1]/preceding::a[2]</value>
      <webElementGuid>0b51dea2-7ec8-49f0-aa5f-dea213b2cf03</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Portrait of Professor Dervilla Donnelly']/parent::*</value>
      <webElementGuid>9d491db4-e0e6-4dd2-888e-e45625716f90</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chem/about/portraitofprofessordervilladonnelly/')]</value>
      <webElementGuid>d8fa9f33-4afe-4ce6-bcc1-4a08ad4ba81d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[8]/a</value>
      <webElementGuid>741265ef-6882-42ed-8b61-97a737ae4468</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chem/about/portraitofprofessordervilladonnelly/' and (text() = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Portrait of Professor Dervilla Donnelly
            ' or . = '
                
                    
                        
                            
                        
                        
                            
                                
                            
                        
                    
                
                Portrait of Professor Dervilla Donnelly
            ')]</value>
      <webElementGuid>e6cefc84-52e2-4e5f-8f86-91174da8243c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
